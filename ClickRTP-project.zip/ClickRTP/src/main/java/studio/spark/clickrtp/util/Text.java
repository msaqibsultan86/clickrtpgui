package studio.spark.clickrtp.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;

public final class Text {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private Text() {}

    public static Component mm(String input) {
        if (input == null) input = "";
        return MM.deserialize(input);
    }

    /** For item names/lore: parse + turn off the default italic. */
    public static Component item(String input) {
        return mm(input).decoration(TextDecoration.ITALIC, false);
    }
}
