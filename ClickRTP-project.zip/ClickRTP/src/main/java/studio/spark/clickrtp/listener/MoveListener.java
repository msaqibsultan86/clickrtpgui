package studio.spark.clickrtp.listener;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import studio.spark.clickrtp.ClickRTP;

public class MoveListener implements Listener {
    private final ClickRTP plugin;

    public MoveListener(ClickRTP plugin) { this.plugin = plugin; }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (!plugin.warmups().isWarming(p)) return;
        if (!plugin.getConfig().getBoolean("settings.cancel-on-move", true)) return;
        Location start = plugin.warmups().startLocation(p);
        if (start == null) return;
        Location to = e.getTo();
        if (to.getBlockX() != start.getBlockX()
                || to.getBlockY() != start.getBlockY()
                || to.getBlockZ() != start.getBlockZ()) {
            plugin.warmups().cancel(p, true);
        }
    }
}
