package studio.spark.clickrtp.rtp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import studio.spark.clickrtp.ClickRTP;
import studio.spark.clickrtp.config.Messages;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class WarmupManager {
    private final ClickRTP plugin;
    private final Map<UUID, Active> active = new HashMap<>();

    private record Active(BukkitRunnable task, Location start) {}

    public WarmupManager(ClickRTP plugin) { this.plugin = plugin; }

    public boolean isWarming(Player p) { return active.containsKey(p.getUniqueId()); }

    public Location startLocation(Player p) {
        Active a = active.get(p.getUniqueId());
        return a == null ? null : a.start();
    }

    private static final String[] COLORS =
        {"#FF3B3B", "#FF8A3B", "#FFD23B", "#8CFF3B", "#3BE0FF"};

    public void start(Player p, World world) {
        Messages m = plugin.messages();
        int warm = plugin.getConfig().getInt("settings.warmup-seconds", 5);

        if (warm <= 0 || p.hasPermission("clickrtp.bypass")) {
            plugin.rtp().teleport(p, world);
            return;
        }

        final Location start = p.getLocation().clone();
        BukkitRunnable task = new BukkitRunnable() {
            int left = warm;
            @Override public void run() {
                if (!p.isOnline()) { cancel(); active.remove(p.getUniqueId()); return; }
                if (left <= 0) {
                    cancel();
                    active.remove(p.getUniqueId());
                    p.sendActionBar(m.plain("searching"));
                    plugin.rtp().teleport(p, world);
                    return;
                }
                String color = COLORS[Math.min(left - 1, COLORS.length - 1)];
                Title.Times times = Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ofMillis(150));
                p.showTitle(Title.title(
                    m.plain("warmup-title"),
                    m.plain("warmup-subtitle", "color", color, "seconds", String.valueOf(left)),
                    times));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1.6f);
                left--;
            }
        };
        active.put(p.getUniqueId(), new Active(task, start));
        task.runTaskTimer(plugin, 0L, 20L);
    }

    public void cancel(Player p, boolean moved) {
        Active a = active.remove(p.getUniqueId());
        if (a == null) return;
        a.task().cancel();
        if (moved) {
            Messages m = plugin.messages();
            p.showTitle(Title.title(m.plain("cancelled-title"), m.plain("cancelled-subtitle")));
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.7f);
        }
    }

    public void clearAll() {
        active.values().forEach(a -> a.task().cancel());
        active.clear();
    }
}
