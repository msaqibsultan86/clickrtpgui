package studio.spark.clickrtp;

import org.bukkit.plugin.java.JavaPlugin;
import studio.spark.clickrtp.command.RtpCommand;
import studio.spark.clickrtp.config.Messages;
import studio.spark.clickrtp.gui.Menus;
import studio.spark.clickrtp.listener.DamageListener;
import studio.spark.clickrtp.listener.GuiListener;
import studio.spark.clickrtp.listener.MoveListener;
import studio.spark.clickrtp.rtp.CooldownManager;
import studio.spark.clickrtp.rtp.RtpManager;
import studio.spark.clickrtp.rtp.WarmupManager;

import java.util.HashMap;
import java.util.Map;

public class ClickRTP extends JavaPlugin {

    private Messages messages;
    private Menus menus;
    private RtpManager rtp;
    private WarmupManager warmups;
    private CooldownManager cooldowns;
    private final Map<String, String> regionMap = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.messages = new Messages(this);
        this.menus = new Menus(this);
        this.rtp = new RtpManager(this);
        this.warmups = new WarmupManager(this);
        this.cooldowns = new CooldownManager(getConfig().getLong("settings.cooldown-seconds", 60));

        RtpCommand cmd = new RtpCommand(this);
        getCommand("rtp").setExecutor(cmd);
        getCommand("clickrtp").setExecutor(cmd);
        getCommand("clickrtp").setTabCompleter(cmd);

        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new MoveListener(this), this);
        getServer().getPluginManager().registerEvents(new DamageListener(this), this);

        getLogger().info("ClickRTP enabled.");
    }

    @Override
    public void onDisable() {
        if (warmups != null) warmups.clearAll();
    }

    public void reloadAll() {
        reloadConfig();
        messages.reload();
        rtp.loadBlocked();
        cooldowns.setSeconds(getConfig().getLong("settings.cooldown-seconds", 60));
    }

    public Messages messages()        { return messages; }
    public Menus menus()              { return menus; }
    public RtpManager rtp()           { return rtp; }
    public WarmupManager warmups()    { return warmups; }
    public CooldownManager cooldowns(){ return cooldowns; }
    public Map<String, String> regionMap() { return regionMap; }
}
