package studio.spark.clickrtp.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import studio.spark.clickrtp.ClickRTP;
import studio.spark.clickrtp.config.Messages;
import studio.spark.clickrtp.util.Text;

import java.util.ArrayList;
import java.util.List;

public class Menus {
    private final ClickRTP plugin;

    public Menus(ClickRTP plugin) { this.plugin = plugin; }

    private Material mat(String name, Material def) {
        try { return Material.valueOf(name.toUpperCase()); } catch (Exception e) { return def; }
    }

    private ItemStack item(Material mat, Component name, List<Component> lore) {
        ItemStack is = new ItemStack(mat);
        ItemMeta meta = is.getItemMeta();
        if (name != null) meta.displayName(name);
        if (lore != null) meta.lore(lore);
        is.setItemMeta(meta);
        return is;
    }

    private void fill(Inventory inv) {
        Material f = mat(plugin.getConfig().getString("menu.filler", "BLACK_STAINED_GLASS_PANE"),
                Material.BLACK_STAINED_GLASS_PANE);
        ItemStack pane = item(f, Text.item(" "), null);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
    }

    // ---------- MAIN ----------
    public void openMain(Player p) {
        int size = plugin.getConfig().getInt("menu.size", 27);
        MenuHolder holder = new MenuHolder(MenuHolder.Type.MAIN, null, null, null);
        Inventory inv = Bukkit.createInventory(holder, size, Text.mm(plugin.getConfig().getString("menu.title", "RTP")));
        holder.setInventory(inv);
        fill(inv);

        ConfigurationSection dims = plugin.getConfig().getConfigurationSection("dimensions");
        if (dims != null) {
            for (String key : dims.getKeys(false)) {
                ConfigurationSection d = dims.getConfigurationSection(key);
                if (d == null || !d.getBoolean("enabled", true)) continue;
                int slot = d.getInt("slot", 11);
                Material m = mat(d.getString("material", "GRASS_BLOCK"), Material.GRASS_BLOCK);
                Component name = Text.item(d.getString("name", key));
                List<Component> lore = new ArrayList<>();
                for (String line : d.getStringList("lore")) lore.add(Text.item(line));
                inv.setItem(slot, item(m, name, lore));
            }
        }
        p.openInventory(inv);
    }

    // ---------- REGION ----------
    public void openRegion(Player p, String dimension) {
        Messages msg = plugin.messages();
        MenuHolder holder = new MenuHolder(MenuHolder.Type.REGION, dimension, null, null);
        Inventory inv = Bukkit.createInventory(holder, 27, msg.plain("region-title"));
        holder.setInventory(inv);
        fill(inv);

        ConfigurationSection regions = plugin.getConfig()
                .getConfigurationSection("dimensions." + dimension + ".regions");
        int[] slots = {11, 15};
        Material[] mats = {Material.RED_CONCRETE, Material.BLUE_CONCRETE};
        if (regions != null) {
            int i = 0;
            for (String rk : regions.getKeys(false)) {
                if (i >= slots.length) break;
                String world = regions.getString(rk + ".world", "world");
                String display = regions.getString(rk + ".display", rk);
                List<Component> lore = new ArrayList<>();
                lore.add(Text.item("<gray>ᴡᴏʀʟᴅ <dark_gray>» <white>" + world));
                lore.add(Text.item(""));
                lore.add(Text.item("<white>ᴄʟɪᴄᴋ ᴛᴏ <gray>ᴄᴏɴᴛɪɴᴜᴇ"));
                ItemStack is = item(mats[i], Text.item(display), lore);
                // encode region key + world into persistent data
                inv.setItem(slots[i], is);
                // store mapping on holder-adjacent list
                plugin.regionMap().put(regionKey(p, slots[i]), rk + "|" + world);
                i++;
            }
        }
        inv.setItem(22, item(Material.ARROW, msg.plain("back"), null));
        p.openInventory(inv);
    }

    // ---------- CONFIRM ----------
    public void openConfirm(Player p, String dimension, String region, String world) {
        Messages msg = plugin.messages();
        MenuHolder holder = new MenuHolder(MenuHolder.Type.CONFIRM, dimension, region, world);
        Inventory inv = Bukkit.createInventory(holder, 27, msg.plain("confirm-title"));
        holder.setInventory(inv);
        fill(inv);
        List<Component> yesLore = List.of(msg.item("confirm-yes-lore", "world", world));
        List<Component> noLore = List.of(msg.item("confirm-no-lore"));
        inv.setItem(11, item(Material.LIME_CONCRETE, msg.item("confirm-yes"), yesLore));
        inv.setItem(15, item(Material.RED_CONCRETE, msg.item("confirm-no"), noLore));
        p.openInventory(inv);
    }

    public static String regionKey(Player p, int slot) {
        return p.getUniqueId() + ":" + slot;
    }
}
