package studio.spark.clickrtp.config;

import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import studio.spark.clickrtp.ClickRTP;
import studio.spark.clickrtp.util.Text;

import java.io.File;
import org.bukkit.configuration.file.YamlConfiguration;

public class Messages {
    private final ClickRTP plugin;
    private FileConfiguration cfg;
    private String prefix = "";

    public Messages(ClickRTP plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File f = new File(plugin.getDataFolder(), "messages.yml");
        if (!f.exists()) plugin.saveResource("messages.yml", false);
        cfg = YamlConfiguration.loadConfiguration(f);
        prefix = cfg.getString("prefix", "");
    }

    public String raw(String path) {
        return cfg.getString(path, path);
    }

    /** Message with prefix, as a Component, with {key} replacements. */
    public Component msg(String path, String... repl) {
        return Text.mm(prefix + apply(raw(path), repl));
    }

    /** Plain component (no prefix). */
    public Component plain(String path, String... repl) {
        return Text.mm(apply(raw(path), repl));
    }

    public Component item(String path, String... repl) {
        return Text.item(apply(raw(path), repl));
    }

    public static String apply(String s, String... repl) {
        for (int i = 0; i + 1 < repl.length; i += 2) {
            s = s.replace("{" + repl[i] + "}", repl[i + 1]);
        }
        return s;
    }
}
