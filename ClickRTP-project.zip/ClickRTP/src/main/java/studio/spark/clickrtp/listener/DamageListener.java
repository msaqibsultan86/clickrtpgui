package studio.spark.clickrtp.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import studio.spark.clickrtp.ClickRTP;

public class DamageListener implements Listener {
    private final ClickRTP plugin;

    public DamageListener(ClickRTP plugin) { this.plugin = plugin; }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (plugin.rtp().isInvincible(p.getUniqueId())) e.setCancelled(true);
    }
}
