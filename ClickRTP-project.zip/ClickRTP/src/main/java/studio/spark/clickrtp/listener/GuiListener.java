package studio.spark.clickrtp.listener;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;
import studio.spark.clickrtp.ClickRTP;
import studio.spark.clickrtp.gui.Menus;
import studio.spark.clickrtp.gui.MenuHolder;

public class GuiListener implements Listener {
    private final ClickRTP plugin;

    public GuiListener(ClickRTP plugin) { this.plugin = plugin; }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        InventoryHolder h = e.getInventory().getHolder();
        if (!(h instanceof MenuHolder holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(e.getView().getTopInventory())) return;

        int slot = e.getRawSlot();

        switch (holder.type) {
            case MAIN -> {
                var dims = plugin.getConfig().getConfigurationSection("dimensions");
                if (dims == null) return;
                for (String key : dims.getKeys(false)) {
                    var d = dims.getConfigurationSection(key);
                    if (d == null || !d.getBoolean("enabled", true)) continue;
                    if (d.getInt("slot", 11) == slot) {
                        click(p);
                        Bukkit.getScheduler().runTask(plugin, () -> plugin.menus().openRegion(p, key));
                        return;
                    }
                }
            }
            case REGION -> {
                if (slot == 22) {
                    click(p);
                    Bukkit.getScheduler().runTask(plugin, () -> plugin.menus().openMain(p));
                    return;
                }
                String data = plugin.regionMap().get(Menus.regionKey(p, slot));
                if (data == null) return;
                String[] parts = data.split("\\|", 2);
                String region = parts[0];
                String world = parts.length > 1 ? parts[1] : "world";
                click(p);
                Bukkit.getScheduler().runTask(plugin, () ->
                        plugin.menus().openConfirm(p, holder.dimension, region, world));
            }
            case CONFIRM -> {
                if (slot == 11) { // confirm
                    p.closeInventory();
                    startTeleport(p, holder.world);
                } else if (slot == 15) { // cancel -> back to region
                    click(p);
                    Bukkit.getScheduler().runTask(plugin, () -> plugin.menus().openRegion(p, holder.dimension));
                }
            }
        }
    }

    private void startTeleport(Player p, String worldName) {
        if (plugin.cooldowns().isOnCooldown(p)) {
            p.sendMessage(plugin.messages().msg("cooldown", "seconds", String.valueOf(plugin.cooldowns().remaining(p))));
            return;
        }
        if (plugin.warmups().isWarming(p) || plugin.rtp().isBusy(p)) {
            p.sendMessage(plugin.messages().msg("already-teleporting"));
            return;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            p.sendMessage(plugin.messages().msg("world-missing"));
            return;
        }
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.3f);
        plugin.warmups().start(p, world);
    }

    private void click(Player p) {
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.4f);
    }
}
