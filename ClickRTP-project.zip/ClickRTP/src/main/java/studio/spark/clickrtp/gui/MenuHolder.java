package studio.spark.clickrtp.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

public class MenuHolder implements InventoryHolder {
    public enum Type { MAIN, REGION, CONFIRM }

    private Inventory inventory;
    public final Type type;
    public final String dimension; // for REGION / CONFIRM
    public final String region;    // for CONFIRM
    public final String world;     // for CONFIRM

    public MenuHolder(Type type, String dimension, String region, String world) {
        this.type = type;
        this.dimension = dimension;
        this.region = region;
        this.world = world;
    }

    public void setInventory(Inventory inv) { this.inventory = inv; }

    @Override public @NotNull Inventory getInventory() { return inventory; }
}
