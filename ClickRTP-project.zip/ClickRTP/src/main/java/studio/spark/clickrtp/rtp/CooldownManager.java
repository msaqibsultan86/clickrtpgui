package studio.spark.clickrtp.rtp;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    private final Map<UUID, Long> until = new HashMap<>();
    private long seconds;

    public CooldownManager(long seconds) { this.seconds = seconds; }

    public void setSeconds(long s) { this.seconds = s; }

    public boolean isOnCooldown(Player p) {
        if (p.hasPermission("clickrtp.bypass")) return false;
        Long u = until.get(p.getUniqueId());
        return u != null && u > System.currentTimeMillis();
    }

    public long remaining(Player p) {
        Long u = until.get(p.getUniqueId());
        if (u == null) return 0;
        return Math.max(0, (u - System.currentTimeMillis() + 999) / 1000);
    }

    public void apply(Player p) {
        if (p.hasPermission("clickrtp.bypass")) return;
        until.put(p.getUniqueId(), System.currentTimeMillis() + seconds * 1000L);
    }

    public void clear(UUID id) { until.remove(id); }
}
