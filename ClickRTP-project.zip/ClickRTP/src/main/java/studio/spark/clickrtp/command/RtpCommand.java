package studio.spark.clickrtp.command;

import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import studio.spark.clickrtp.ClickRTP;

import java.util.ArrayList;
import java.util.List;

public class RtpCommand implements TabExecutor {
    private final ClickRTP plugin;

    public RtpCommand(ClickRTP plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {

        if (command.getName().equalsIgnoreCase("clickrtp")) {
            if (!sender.hasPermission("clickrtp.admin")) {
                sender.sendMessage(plugin.messages().msg("no-permission"));
                return true;
            }
            if (args.length == 0) {
                sender.sendMessage(plugin.messages().msg("usage-admin"));
                return true;
            }
            switch (args[0].toLowerCase()) {
                case "reload" -> {
                    plugin.reloadAll();
                    sender.sendMessage(plugin.messages().msg("reloaded"));
                }
                case "rtpdistance" -> {
                    if (args.length >= 3 && args[1].equalsIgnoreCase("set")) {
                        int n;
                        try { n = Integer.parseInt(args[2]); }
                        catch (NumberFormatException ex) {
                            sender.sendMessage(plugin.messages().msg("invalid-number"));
                            return true;
                        }
                        if (n <= 0) { sender.sendMessage(plugin.messages().msg("invalid-number")); return true; }
                        plugin.getConfig().set("settings.max-radius", n);
                        plugin.saveConfig();
                        plugin.reloadAll();
                        sender.sendMessage(plugin.messages().msg("distance-set", "blocks", String.valueOf(n)));
                    } else {
                        int cur = plugin.getConfig().getInt("settings.max-radius", 10000);
                        sender.sendMessage(plugin.messages().msg("distance-current", "blocks", String.valueOf(cur)));
                        sender.sendMessage(plugin.messages().msg("usage-admin"));
                    }
                }
                default -> sender.sendMessage(plugin.messages().msg("usage-admin"));
            }
            return true;
        }

        // /rtp
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.messages().msg("players-only"));
            return true;
        }
        if (!p.hasPermission("clickrtp.use")) {
            p.sendMessage(plugin.messages().msg("no-permission"));
            return true;
        }
        plugin.menus().openMain(p);
        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                @NotNull String alias, @NotNull String[] args) {
        List<String> out = new ArrayList<>();
        if (!command.getName().equalsIgnoreCase("clickrtp")) return out;
        if (!sender.hasPermission("clickrtp.admin")) return out;

        if (args.length == 1) {
            for (String s : List.of("reload", "rtpdistance"))
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("rtpdistance")) {
            if ("set".startsWith(args[1].toLowerCase())) out.add("set");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("rtpdistance")
                && args[1].equalsIgnoreCase("set")) {
            out.add("10000");
        }
        return out;
    }
}
