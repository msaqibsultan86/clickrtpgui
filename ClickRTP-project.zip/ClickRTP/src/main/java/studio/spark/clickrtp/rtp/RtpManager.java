package studio.spark.clickrtp.rtp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import studio.spark.clickrtp.ClickRTP;
import studio.spark.clickrtp.config.Messages;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class RtpManager {
    private final ClickRTP plugin;
    private final Set<UUID> busy = new HashSet<>();
    private final Set<UUID> invincible = new HashSet<>();
    private final Set<Material> blocked = EnumSet.noneOf(Material.class);

    public RtpManager(ClickRTP plugin) {
        this.plugin = plugin;
        loadBlocked();
    }

    public void loadBlocked() {
        blocked.clear();
        for (String s : plugin.getConfig().getStringList("settings.blocked-blocks")) {
            try { blocked.add(Material.valueOf(s.toUpperCase())); } catch (IllegalArgumentException ignored) {}
        }
    }

    public boolean isInvincible(UUID id) { return invincible.contains(id); }
    public boolean isBusy(Player p) { return busy.contains(p.getUniqueId()); }

    public void teleport(Player p, World world) {
        if (world == null) { p.sendMessage(plugin.messages().msg("world-missing")); return; }
        if (busy.contains(p.getUniqueId())) return;
        busy.add(p.getUniqueId());
        attempt(p, world, 0);
    }

    private void attempt(Player p, World world, int tries) {
        int max = plugin.getConfig().getInt("settings.max-attempts", 60);
        if (!p.isOnline() || tries >= max) {
            busy.remove(p.getUniqueId());
            if (p.isOnline()) p.sendMessage(plugin.messages().msg("failed"));
            return;
        }
        int cx = plugin.getConfig().getInt("settings.center-x", 0);
        int cz = plugin.getConfig().getInt("settings.center-z", 0);
        int min = plugin.getConfig().getInt("settings.min-radius", 500);
        int maxR = plugin.getConfig().getInt("settings.max-radius", 5000);

        int x = cx + randSigned(min, maxR);
        int z = cz + randSigned(min, maxR);

        world.getChunkAtAsync(x >> 4, z >> 4).thenAccept(chunk ->
            Bukkit.getScheduler().runTask(plugin, () -> {
                Location safe = findSafe(world, x, z);
                if (safe == null) {
                    attempt(p, world, tries + 1);
                } else {
                    doTeleport(p, safe);
                }
            }));
    }

    private int randSigned(int min, int max) {
        int v = ThreadLocalRandom.current().nextInt(min, max + 1);
        return ThreadLocalRandom.current().nextBoolean() ? v : -v;
    }

    private Location findSafe(World world, int x, int z) {
        World.Environment env = world.getEnvironment();
        if (env == World.Environment.NETHER) {
            for (int y = 118; y > 5; y--) {
                Location l = checkColumn(world, x, y, z);
                if (l != null) return l;
            }
            return null;
        }
        int y = world.getHighestBlockYAt(x, z);
        return checkColumn(world, x, y, z);
    }

    private Location checkColumn(World world, int x, int y, int z) {
        Block ground = world.getBlockAt(x, y, z);
        Block feet = world.getBlockAt(x, y + 1, z);
        Block head = world.getBlockAt(x, y + 2, z);
        if (!ground.getType().isSolid()) return null;
        if (blocked.contains(ground.getType())) return null;
        if (!feet.isPassable() || !head.isPassable()) return null;
        if (blocked.contains(feet.getType()) || blocked.contains(head.getType())) return null;
        return new Location(world, x + 0.5, y + 1, z + 0.5, 0f, 0f);
    }

    private void doTeleport(Player p, Location loc) {
        busy.remove(p.getUniqueId());
        p.teleportAsync(loc).thenAccept(ok -> {
            if (!ok) return;
            Messages m = plugin.messages();
            p.showTitle(Title.title(
                m.plain("success-title"),
                m.plain("success-subtitle",
                    "x", String.valueOf(loc.getBlockX()),
                    "y", String.valueOf(loc.getBlockY()),
                    "z", String.valueOf(loc.getBlockZ()))));
            p.playSound(loc, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
            p.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.4f);
            p.getWorld().spawnParticle(Particle.EXPLOSION, loc, 1);
            p.getWorld().spawnParticle(Particle.CRIT, loc, 25, 0.4, 0.6, 0.4, 0.2);

            plugin.cooldowns().apply(p);
            grantInvincibility(p);
        });
    }

    private void grantInvincibility(Player p) {
        int secs = plugin.getConfig().getInt("settings.invincibility-seconds", 5);
        if (secs <= 0) return;
        invincible.add(p.getUniqueId());
        p.setNoDamageTicks(secs * 20);
        Bukkit.getScheduler().runTaskLater(plugin, () -> invincible.remove(p.getUniqueId()), secs * 20L);
    }

    public void clearBusy(UUID id) { busy.remove(id); }
}
