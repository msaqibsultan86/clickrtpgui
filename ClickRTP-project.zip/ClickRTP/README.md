# ClickRTP

Premium click-to-RTP GUI plugin for Paper 1.21.x (Java 21) — by Spark Studios.

## Flow
`/rtp` → dimension (Overworld / Nether / End) → region (Asia / Europe, each can be a
different world) → **confirm ✓/✗** → **5s countdown** (cancels if you move) → async
safe-spot teleport → success title + 5s invincibility. 60s cooldown.

## Build (GitHub Actions)
Push to `main`. The workflow in `.github/workflows/build.yml` builds the jar and
uploads it as an artifact named **ClickRTP** (`target/ClickRTP.jar`).

Or build locally:
```
mvn clean package
```
Jar lands in `target/ClickRTP.jar`.

## Commands
- `/rtp` (aliases `/wild`, `/randomtp`) — open the menu
- `/clickrtp reload` (alias `/crtp`) — reload config

## Permissions
- `clickrtp.use` (default: true)
- `clickrtp.bypass` (default: op) — skip cooldown + warmup
- `clickrtp.admin` (default: op) — reload

## Config
`config.yml` — cooldown, warmup, radius, blocked blocks, per-dimension regions/worlds.
`messages.yml` — all text (MiniMessage). Change region worlds under `dimensions.<dim>.regions`.
